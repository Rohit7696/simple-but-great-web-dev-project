
// server.js

require('dotenv').config();  // Load environment variables from .env file
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/authRoutes');  // Import the auth routes

const app = express();

// Middleware
app.use(cors());               // Enable Cross-Origin Resource Sharing
app.use(express.json());        // Parse incoming JSON requests
app.use(express.urlencoded({ extended: true }));  // Parse incoming url-encoded data

// MongoDB connection
const DB_URI = process.env.DB_URI;  // MongoDB URI from the environment variable

mongoose.connect(DB_URI)  // No need for deprecated options anymore
    .then(() => {
        console.log('Connected to MongoDB');  // Success message
    })
    .catch((err) => {
        console.error('Failed to connect to MongoDB', err);  // Error handling if MongoDB connection fails
    });

// Use the authentication routes
app.use('/auth', authRoutes);  // All /auth routes will be handled by authRoutes

// Start the server
const PORT = process.env.PORT || 5000;  // Port from environment variable or fallback to 5000
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);  // Log that server is running
});
